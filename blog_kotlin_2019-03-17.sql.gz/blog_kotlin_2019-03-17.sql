﻿# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.21)
# Database: blog_kotlin
# Generation Time: 2019-03-17 22:04:17 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table admins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `admins`;

CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text,
  `pass` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;

INSERT INTO `admins` (`id`, `username`, `pass`)
VALUES
	(1,'admin','$2a$10$i1sLYXIksrh9GhbSgs37BOZz2oCg00lcCPa.WWR4iZF19lcouUktC');

/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table articles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `articles`;

CREATE TABLE `articles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;

INSERT INTO `articles` (`id`, `title`, `text`)
VALUES
	(9,'Titre de l\'article 1','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Tempor nec feugiat nisl pretium fusce. Nisl pretium fusce id velit ut tortor pretium viverra suspendisse. Semper viverra nam libero justo laoreet sit amet cursus. Dignissim diam quis enim lobortis scelerisque fermentum. Ornare suspendisse sed nisi lacus sed viverra. Urna neque viverra justo nec ultrices dui sapien eget mi. Enim sit amet venenatis urna cursus eget. Sodales ut etiam sit amet nisl purus in mollis. Euismod quis viverra nibh cras pulvinar mattis. Leo urna molestie at elementum eu facilisis sed odio morbi. Nibh nisl condimentum id venenatis a condimentum vitae sapien pellentesque. Lacus laoreet non curabitur gravida arcu ac tortor dignissim convallis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Quis varius quam quisque id. Id donec ultrices tincidunt arcu non. Est lorem ipsum dolor sit. Lectus nulla at volutpat diam. Ut diam quam nulla porttitor massa id.\r\n\r\nAt volutpat diam ut venenatis tellus. Ultricies mi quis hendrerit dolor magna eget est. Pellentesque sit amet porttitor eget dolor morbi non. Viverra tellus in hac habitasse platea. Risus nec feugiat in fermentum posuere urna. Id donec ultrices tincidunt arcu non sodales neque. Est placerat in egestas erat. Eget arcu dictum varius duis at consectetur lorem donec. Id eu nisl nunc mi ipsum. Et netus et malesuada fames ac turpis egestas maecenas. Id semper risus in hendrerit gravida rutrum.\r\n\r\nRutrum quisque non tellus orci ac auctor augue mauris. Purus semper eget duis at tellus. Arcu cursus euismod quis viverra nibh cras pulvinar mattis nunc. Tincidunt arcu non sodales neque sodales ut etiam. Viverra vitae congue eu consequat. Porttitor eget dolor morbi non arcu risus quis varius. In nulla posuere sollicitudin aliquam. Amet nulla facilisi morbi tempus. Facilisis volutpat est velit egestas. Malesuada nunc vel risus commodo viverra maecenas accumsan lacus. Lectus proin nibh nisl condimentum id venenatis a. Laoreet suspendisse interdum consectetur libero id faucibus nisl. Lacus suspendisse faucibus interdum posuere lorem ipsum. Amet dictum sit amet justo donec enim diam vulputate. In ante metus dictum at tempor. Risus at ultrices mi tempus imperdiet nulla malesuada pellentesque. Porta non pulvinar neque laoreet suspendisse interdum. Fringilla urna porttitor rhoncus dolor purus. Elementum curabitur vitae nunc sed velit dignissim sodales ut eu.\r\n\r\nFelis donec et odio pellentesque diam volutpat. Orci eu lobortis elementum nibh. Viverra justo nec ultrices dui sapien eget mi proin. Ut morbi tincidunt augue interdum. Duis ultricies lacus sed turpis tincidunt id aliquet. Ipsum nunc aliquet bibendum enim facilisis gravida neque convallis a. Elementum nisi quis eleifend quam adipiscing vitae proin sagittis nisl. Accumsan tortor posuere ac ut consequat semper viverra nam libero. Est ante in nibh mauris cursus mattis molestie a iaculis. Adipiscing vitae proin sagittis nisl rhoncus mattis rhoncus. Lacus laoreet non curabitur gravida. Lectus sit amet est placerat in egestas. Vulputate mi sit amet mauris commodo quis. A lacus vestibulum sed arcu non odio.\r\n\r\n'),
	(10,'Titre de l\'article 2','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Tempor nec feugiat nisl pretium fusce. Nisl pretium fusce id velit ut tortor pretium viverra suspendisse. Semper viverra nam libero justo laoreet sit amet cursus. Dignissim diam quis enim lobortis scelerisque fermentum. Ornare suspendisse sed nisi lacus sed viverra. Urna neque viverra justo nec ultrices dui sapien eget mi. Enim sit amet venenatis urna cursus eget. Sodales ut etiam sit amet nisl purus in mollis. Euismod quis viverra nibh cras pulvinar mattis. Leo urna molestie at elementum eu facilisis sed odio morbi. Nibh nisl condimentum id venenatis a condimentum vitae sapien pellentesque. Lacus laoreet non curabitur gravida arcu ac tortor dignissim convallis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Quis varius quam quisque id. Id donec ultrices tincidunt arcu non. Est lorem ipsum dolor sit. Lectus nulla at volutpat diam. Ut diam quam nulla porttitor massa id.\r\n\r\nAt volutpat diam ut venenatis tellus. Ultricies mi quis hendrerit dolor magna eget est. Pellentesque sit amet porttitor eget dolor morbi non. Viverra tellus in hac habitasse platea. Risus nec feugiat in fermentum posuere urna. Id donec ultrices tincidunt arcu non sodales neque. Est placerat in egestas erat. Eget arcu dictum varius duis at consectetur lorem donec. Id eu nisl nunc mi ipsum. Et netus et malesuada fames ac turpis egestas maecenas. Id semper risus in hendrerit gravida rutrum.\r\n\r\nRutrum quisque non tellus orci ac auctor augue mauris. Purus semper eget duis at tellus. Arcu cursus euismod quis viverra nibh cras pulvinar mattis nunc. Tincidunt arcu non sodales neque sodales ut etiam. Viverra vitae congue eu consequat. Porttitor eget dolor morbi non arcu risus quis varius. In nulla posuere sollicitudin aliquam. Amet nulla facilisi morbi tempus. Facilisis volutpat est velit egestas. Malesuada nunc vel risus commodo viverra maecenas accumsan lacus. Lectus proin nibh nisl condimentum id venenatis a. Laoreet suspendisse interdum consectetur libero id faucibus nisl. Lacus suspendisse faucibus interdum posuere lorem ipsum. Amet dictum sit amet justo donec enim diam vulputate. In ante metus dictum at tempor. Risus at ultrices mi tempus imperdiet nulla malesuada pellentesque. Porta non pulvinar neque laoreet suspendisse interdum. Fringilla urna porttitor rhoncus dolor purus. Elementum curabitur vitae nunc sed velit dignissim sodales ut eu.\r\n\r\nFelis donec et odio pellentesque diam volutpat. Orci eu lobortis elementum nibh. Viverra justo nec ultrices dui sapien eget mi proin. Ut morbi tincidunt augue interdum. Duis ultricies lacus sed turpis tincidunt id aliquet. Ipsum nunc aliquet bibendum enim facilisis gravida neque convallis a. Elementum nisi quis eleifend quam adipiscing vitae proin sagittis nisl. Accumsan tortor posuere ac ut consequat semper viverra nam libero. Est ante in nibh mauris cursus mattis molestie a iaculis. Adipiscing vitae proin sagittis nisl rhoncus mattis rhoncus. Lacus laoreet non curabitur gravida. Lectus sit amet est placerat in egestas. Vulputate mi sit amet mauris commodo quis. A lacus vestibulum sed arcu non odio.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Tempor nec feugiat nisl pretium fusce. Nisl pretium fusce id velit ut tortor pretium viverra suspendisse. Semper viverra nam libero justo laoreet sit amet cursus. Dignissim diam quis enim lobortis scelerisque fermentum. Ornare suspendisse sed nisi lacus sed viverra. Urna neque viverra justo nec ultrices dui sapien eget mi. Enim sit amet venenatis urna cursus eget. Sodales ut etiam sit amet nisl purus in mollis. Euismod quis viverra nibh cras pulvinar mattis. Leo urna molestie at elementum eu facilisis sed odio morbi. Nibh nisl condimentum id venenatis a condimentum vitae sapien pellentesque. Lacus laoreet non curabitur gravida arcu ac tortor dignissim convallis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Quis varius quam quisque id. Id donec ultrices tincidunt arcu non. Est lorem ipsum dolor sit. Lectus nulla at volutpat diam. Ut diam quam nulla porttitor massa id.\r\n\r\nAt volutpat diam ut venenatis tellus. Ultricies mi quis hendrerit dolor magna eget est. Pellentesque sit amet porttitor eget dolor morbi non. Viverra tellus in hac habitasse platea. Risus nec feugiat in fermentum posuere urna. Id donec ultrices tincidunt arcu non sodales neque. Est placerat in egestas erat. Eget arcu dictum varius duis at consectetur lorem donec. Id eu nisl nunc mi ipsum. Et netus et malesuada fames ac turpis egestas maecenas. Id semper risus in hendrerit gravida rutrum.\r\n\r\nRutrum quisque non tellus orci ac auctor augue mauris. Purus semper eget duis at tellus. Arcu cursus euismod quis viverra nibh cras pulvinar mattis nunc. Tincidunt arcu non sodales neque sodales ut etiam. Viverra vitae congue eu consequat. Porttitor eget dolor morbi non arcu risus quis varius. In nulla posuere sollicitudin aliquam. Amet nulla facilisi morbi tempus. Facilisis volutpat est velit egestas. Malesuada nunc vel risus commodo viverra maecenas accumsan lacus. Lectus proin nibh nisl condimentum id venenatis a. Laoreet suspendisse interdum consectetur libero id faucibus nisl. Lacus suspendisse faucibus interdum posuere lorem ipsum. Amet dictum sit amet justo donec enim diam vulputate. In ante metus dictum at tempor. Risus at ultrices mi tempus imperdiet nulla malesuada pellentesque. Porta non pulvinar neque laoreet suspendisse interdum. Fringilla urna porttitor rhoncus dolor purus. Elementum curabitur vitae nunc sed velit dignissim sodales ut eu.\r\n\r\nFelis donec et odio pellentesque diam volutpat. Orci eu lobortis elementum nibh. Viverra justo nec ultrices dui sapien eget mi proin. Ut morbi tincidunt augue interdum. Duis ultricies lacus sed turpis tincidunt id aliquet. Ipsum nunc aliquet bibendum enim facilisis gravida neque convallis a. Elementum nisi quis eleifend quam adipiscing vitae proin sagittis nisl. Accumsan tortor posuere ac ut consequat semper viverra nam libero. Est ante in nibh mauris cursus mattis molestie a iaculis. Adipiscing vitae proin sagittis nisl rhoncus mattis rhoncus. Lacus laoreet non curabitur gravida. Lectus sit amet est placerat in egestas. Vulputate mi sit amet mauris commodo quis. A lacus vestibulum sed arcu non odio.\r\n\r\n');

/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(11) unsigned NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article__comments` (`article_id`),
  CONSTRAINT `article__comments` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;

INSERT INTO `comments` (`id`, `article_id`, `comment`)
VALUES
	(19,9,'Un commentaire sur l\'article 1'),
	(20,9,'un commentaire à supprimer sur l\'article 1'),
	(21,10,'Un comm sur l\'article 2'),
	(22,10,'Un commentaire à supprimer sur l\'article 2');

/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
